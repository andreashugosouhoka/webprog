<?php
$host = "localhost";
$username = "root";
$password = ""; 
$database = "siswa"; 

$pdo = new PDO('mysql:host='.$host.';dbname='.$database, $username, $password);
?>